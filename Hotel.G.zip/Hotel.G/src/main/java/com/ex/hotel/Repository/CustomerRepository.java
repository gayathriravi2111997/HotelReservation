package com.ex.hotel.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ex.hotel.Model.Customer;
@Repository
public interface CustomerRepository extends JpaRepository<Customer,Long>{

	//List<Customer> findAll();

	//Customer save(Customer customer);

	//Optional<Customer> findById(Long id);

}
