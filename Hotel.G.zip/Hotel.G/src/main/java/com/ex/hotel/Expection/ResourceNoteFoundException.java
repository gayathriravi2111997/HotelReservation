package com.ex.hotel.Expection;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND)

public class ResourceNoteFoundException extends RuntimeException{
private static final long serialVersionUID = 1L;
	
	public ResourceNoteFoundException(String message) {
		super(message);
	}
}


/*
package com.example.Expection;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND)

public class ResourceNoteFoundException extends RuntimeException {
private static final long serialVersionUID = 1L;
	
	public ResourceNoteFoundException(String message) {
		super(message);
	}
}*/
